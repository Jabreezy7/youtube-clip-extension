# youtube-clip-extension

Scissor icons created by Iconjam - Flaticon(https://www.flaticon.com/free-icons/construction-and-tools)
